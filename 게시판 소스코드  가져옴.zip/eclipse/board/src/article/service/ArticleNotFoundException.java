package article.service;

public class ArticleNotFoundException extends RuntimeException {

}
